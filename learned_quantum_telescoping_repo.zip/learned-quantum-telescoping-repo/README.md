# Learned Quantum Telescoping — Reproducibility Repo (Part VIII)

Minimal, self-contained code to reproduce the paper's numerics:
- 4-qubit 1D transverse-field Ising: \hat d_{\mu,O}(N) vs N for baseline vs refined splitting
- Optional depolarizing noise stress test (p=1e-3) and ratio base/refined
- Optional 8-qubit extension

## Setup
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
```

## Run (4 qubits, figure)
```bash
python -m src.simulate --n 4 --t 1.0 --J 1.0 --h 0.5 --m 200 --seed 7 --make-figure
```

## Run (noise stress test)
```bash
python -m src.simulate --n 4 --t 1.0 --J 1.0 --h 0.5 --m 200 --seed 7 --noise depolarizing --p 1e-3 --ratio-N 20
```

## Run (8 qubits)
```bash
python -m src.simulate --n 8 --t 1.0 --J 1.0 --h 1.0 --m 80 --seed 7 --make-figure
```

Outputs:
- figures/figure4_like.png
- results/example_9_3_*qubit.json
- results/noise_stress_test.json
