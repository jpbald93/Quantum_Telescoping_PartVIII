from __future__ import annotations
import qutip as qt
from .paulis import pauli_matrices

def ising_tf_hamiltonian(n: int, J: float, h: float) -> qt.Qobj:
    # H = -J sum Z_i Z_{i+1} - h sum X_i
    Iq = qt.qeye(2); Zq = qt.sigmaz(); Xq = qt.sigmax()
    H = 0
    for j in range(n-1):
        ops=[Iq]*n
        ops[j]=Zq; ops[j+1]=Zq
        H += (-J)*qt.tensor(ops)
    for j in range(n):
        ops=[Iq]*n
        ops[j]=Xq
        H += (-h)*qt.tensor(ops)
    return H

def split_ZZ_even_odd(n: int, J: float):
    Iq = qt.qeye(2); Zq = qt.sigmaz()
    He=0; Ho=0
    for j in range(n-1):
        ops=[Iq]*n
        ops[j]=Zq; ops[j+1]=Zq
        term=(-J)*qt.tensor(ops)
        (Ho if (j%2)==0 else He) += term
    return He,Ho

def split_X_even_odd(n: int, h: float):
    Iq = qt.qeye(2); Xq = qt.sigmax()
    He=0; Ho=0
    for j in range(n):
        ops=[Iq]*n
        ops[j]=Xq
        term=(-h)*qt.tensor(ops)
        (He if (j%2)==0 else Ho) += term
    return He,Ho
