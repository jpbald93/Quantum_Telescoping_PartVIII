from __future__ import annotations
import numpy as np
from typing import List, Tuple

def pauli_matrices() -> Tuple[np.ndarray,np.ndarray,np.ndarray,np.ndarray]:
    I = np.array([[1,0],[0,1]], dtype=complex)
    X = np.array([[0,1],[1,0]], dtype=complex)
    Y = np.array([[0,-1j],[1j,0]], dtype=complex)
    Z = np.array([[1,0],[0,-1]], dtype=complex)
    return I,X,Y,Z

def kron_n(ops: List[np.ndarray]) -> np.ndarray:
    out = ops[0]
    for op in ops[1:]:
        out = np.kron(out, op)
    return out

def local_single_qubit_paulis(n: int) -> List[np.ndarray]:
    I,X,Y,Z = pauli_matrices()
    obs=[]
    for j in range(n):
        for P in (X,Y,Z):
            ops=[I]*n
            ops[j]=P
            obs.append(kron_n(ops))
    return obs
