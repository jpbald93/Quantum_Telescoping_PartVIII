from __future__ import annotations
import numpy as np
import qutip as qt
from typing import Optional, Callable

def apply_unitary(U: qt.Qobj, rho: np.ndarray) -> np.ndarray:
    rq = qt.Qobj(rho, dims=U.dims)
    out = U * rq * U.dag()
    return out.full()

def depolarize(rho: np.ndarray, p: float) -> np.ndarray:
    d = rho.shape[0]
    return (1-p)*rho + p*np.eye(d, dtype=complex)/d

def with_noise(apply_block: Callable[[np.ndarray], np.ndarray], noise: str, p: float) -> Callable[[np.ndarray], np.ndarray]:
    if noise == "none" or p == 0.0:
        return apply_block
    if noise != "depolarizing":
        raise ValueError("noise must be none|depolarizing")
    def f(rho: np.ndarray) -> np.ndarray:
        return depolarize(apply_block(rho), p)
    return f
