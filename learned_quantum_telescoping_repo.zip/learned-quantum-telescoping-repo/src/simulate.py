from __future__ import annotations
import argparse, json, os
from typing import List, Tuple
import numpy as np
import matplotlib.pyplot as plt
import qutip as qt

from .utils import set_seed, haar_random_pure_state, ket_to_density, rms_observable_error, ensure_psd_trace1
from .paulis import local_single_qubit_paulis
from .ising import ising_tf_hamiltonian, split_ZZ_even_odd, split_X_even_odd
from .channels import apply_unitary, with_noise

def strang_step(HZZ: qt.Qobj, HX: qt.Qobj, dt: float) -> qt.Qobj:
    return (-1j*HZZ*(dt/2)).expm() * (-1j*HX*dt).expm() * (-1j*HZZ*(dt/2)).expm()

def refined_step(HZZ_even: qt.Qobj, HZZ_odd: qt.Qobj, HX_even: qt.Qobj, HX_odd: qt.Qobj, dt: float) -> qt.Qobj:
    # palindromic over a finer partition
    return (
        (-1j*HZZ_odd*(dt/2)).expm()
        * (-1j*HZZ_even*(dt/2)).expm()
        * (-1j*HX_even*(dt/2)).expm()
        * (-1j*HX_odd*dt).expm()
        * (-1j*HX_even*(dt/2)).expm()
        * (-1j*HZZ_even*(dt/2)).expm()
        * (-1j*HZZ_odd*(dt/2)).expm()
    )

def fit_power(Ns: List[int], ys: List[float]) -> Tuple[float,float]:
    x=np.log(np.array(Ns,float)); y=np.log(np.array(ys,float))
    A=np.vstack([np.ones_like(x), -x]).T
    coeff, *_ = np.linalg.lstsq(A,y,rcond=None)
    C=float(np.exp(coeff[0])); alpha=float(coeff[1])
    return alpha,C

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=4)
    ap.add_argument("--t", type=float, default=1.0)
    ap.add_argument("--J", type=float, default=1.0)
    ap.add_argument("--h", type=float, default=0.5)
    ap.add_argument("--m", type=int, default=200)
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--Ns", type=str, default="")
    ap.add_argument("--make-figure", action="store_true")
    ap.add_argument("--noise", type=str, default="none", choices=["none","depolarizing"])
    ap.add_argument("--p", type=float, default=0.0)
    ap.add_argument("--ratio-N", type=int, default=20)
    args=ap.parse_args()

    Ns = [5,8,10,12,16,20,25,32,40,50] if not args.Ns.strip() else [int(x) for x in args.Ns.split(",") if x.strip()]
    rng=set_seed(args.seed)
    dim=2**args.n

    # Observables
    obs=local_single_qubit_paulis(args.n)

    # Hamiltonian and target unitary
    H=ising_tf_hamiltonian(args.n, args.J, args.h)
    U_target = (-1j*H*args.t).expm()

    # Split
    HZZ_even,HZZ_odd = split_ZZ_even_odd(args.n, args.J)
    HZZ = HZZ_even + HZZ_odd
    HX_even,HX_odd = split_X_even_odd(args.n, args.h)
    HX = HX_even + HX_odd

    # states
    rhos=[]
    for _ in range(args.m):
        psi=haar_random_pure_state(dim,rng)
        rhos.append(ket_to_density(psi))

    base_vals=[]; ref_vals=[]
    apply_target = with_noise(lambda r: apply_unitary(U_target,r), args.noise, args.p)

    for N in Ns:
        dt=args.t/float(N)
        Ub = (strang_step(HZZ,HX,dt))**N
        Ur = (refined_step(HZZ_even,HZZ_odd,HX_even,HX_odd,dt))**N
        apply_b = with_noise(lambda r, U=Ub: apply_unitary(U,r), args.noise, args.p)
        apply_r = with_noise(lambda r, U=Ur: apply_unitary(U,r), args.noise, args.p)

        rhoT=[ensure_psd_trace1(apply_target(r)) for r in rhos]
        rhoB=[ensure_psd_trace1(apply_b(r)) for r in rhos]
        rhoR=[ensure_psd_trace1(apply_r(r)) for r in rhos]

        base_vals.append(rms_observable_error(obs, rhoB, rhoT))
        ref_vals.append(rms_observable_error(obs, rhoR, rhoT))

    aB,CB = fit_power(Ns, base_vals)
    aR,CR = fit_power(Ns, ref_vals)

    os.makedirs("results", exist_ok=True)
    os.makedirs("figures", exist_ok=True)

    out = {
        "n_qubits": args.n, "t": args.t, "J": args.J, "h": args.h,
        "m_states": args.m, "seed": args.seed, "noise": args.noise, "p": args.p,
        "Ns": Ns, "dmuO_base": base_vals, "dmuO_refined": ref_vals,
        "fit": {"base": {"alpha": aB, "C": CB}, "refined": {"alpha": aR, "C": CR}, "C_ratio_ref_over_base": (CR/CB if CB>0 else None)}
    }
    with open(f"results/example_9_3_{args.n}qubit.json","w") as f:
        json.dump(out,f,indent=2)

    # ratio at N0
    N0=args.ratio_N
    if N0 in Ns:
        i=Ns.index(N0); b0=base_vals[i]; r0=ref_vals[i]
    else:
        # quick compute at N0
        dt=args.t/float(N0)
        Ub=(strang_step(HZZ,HX,dt))**N0
        Ur=(refined_step(HZZ_even,HZZ_odd,HX_even,HX_odd,dt))**N0
        apply_b = with_noise(lambda r, U=Ub: apply_unitary(U,r), args.noise, args.p)
        apply_r = with_noise(lambda r, U=Ur: apply_unitary(U,r), args.noise, args.p)
        rhoT=[ensure_psd_trace1(apply_target(r)) for r in rhos]
        rhoB=[ensure_psd_trace1(apply_b(r)) for r in rhos]
        rhoR=[ensure_psd_trace1(apply_r(r)) for r in rhos]
        b0=rms_observable_error(obs,rhoB,rhoT); r0=rms_observable_error(obs,rhoR,rhoT)
    ratio=float(b0/r0) if r0>0 else None
    with open("results/noise_stress_test.json","w") as f:
        json.dump({"ratio_N": N0, "dmuO_base": float(b0), "dmuO_refined": float(r0), "ratio_base_over_refined": ratio, "noise": args.noise, "p": args.p, "n_qubits": args.n}, f, indent=2)

    if args.make_figure:
        plt.figure()
        plt.loglog(Ns, base_vals, marker="s", label="Baseline Strang")
        plt.loglog(Ns, ref_vals, marker="^", label="Refined partition")
        # reference slope -2 anchored at first point
        Nref=float(Ns[0]); yref=float(base_vals[0])
        refline=[yref*(float(N)/Nref)**(-2.0) for N in Ns]
        plt.loglog(Ns, refline, linestyle="--", label=r"$\\propto N^{-2}$ (ref)")
        plt.xlabel("Trotter steps N")
        plt.ylabel(r"$\\widehat d_{\\mu,O}$")
        plt.legend()
        plt.tight_layout()
        plt.savefig("figures/figure4_like.png", dpi=200)

    print("Wrote results/ and figures/ (if requested).")
    print(f"Fit base: alpha={aB:.3f}, C={CB:.3e}; refined: alpha={aR:.3f}, C={CR:.3e}; ratio@N={N0}: {ratio:.3f}" if ratio is not None else "ratio NA")

if __name__ == "__main__":
    main()
