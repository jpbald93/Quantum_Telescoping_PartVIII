from __future__ import annotations
import numpy as np
from typing import Sequence

def set_seed(seed: int) -> np.random.Generator:
    return np.random.default_rng(seed)

def haar_random_pure_state(dim: int, rng: np.random.Generator) -> np.ndarray:
    v = rng.normal(size=dim) + 1j*rng.normal(size=dim)
    v = v / np.linalg.norm(v)
    return v

def ket_to_density(psi: np.ndarray) -> np.ndarray:
    return np.outer(psi, np.conjugate(psi))

def rms_observable_error(
    observables: Sequence[np.ndarray],
    rho_approx_list: Sequence[np.ndarray],
    rho_target_list: Sequence[np.ndarray],
) -> float:
    m = len(rho_target_list)
    acc = 0.0
    for i in range(m):
        diff = rho_approx_list[i] - rho_target_list[i]
        for O in observables:
            val = np.trace(O @ diff)
            acc += (np.abs(val)**2).real
    return float(np.sqrt(acc/(m*len(observables))))

def ensure_psd_trace1(rho: np.ndarray, tol: float = 1e-12) -> np.ndarray:
    rho = 0.5*(rho + rho.conjugate().T)
    w, v = np.linalg.eigh(rho)
    w = np.clip(w, 0.0, None)
    rho2 = (v*w) @ v.conjugate().T
    tr = np.trace(rho2).real
    if tr < tol:
        raise ValueError("Trace too small.")
    return rho2/tr
